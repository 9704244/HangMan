class Pipe:
    import pygame

    width = 200
    height = 200
    xpos = width/2
    ypos = height/2

    loadPipe = pygame.image.load("SKPipe.png")

    pipeSize = pygame.transform.scale(loadPipe, (width, height))