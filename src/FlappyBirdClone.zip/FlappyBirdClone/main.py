# Made by Symon Kim
import pygame
pygame.init()

width = 500
height = 500
xpos = width/2
ypos = height/2
screen = pygame.display.set_mode((width, height))
loadStart = pygame.image.load("SKStartScreen.png")
startScreenSize = pygame.transform.scale(loadStart, (width, height))
loadStarted = pygame.image.load("SKStarted.png")
startedSize = pygame.transform.scale(loadStarted, (width, height))
loadScreen = startScreenSize

quit = False

running = True

while running == True:
    screen.blit(loadScreen, (0,0))
    pygame.display.update()

    # Exit Code

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            loadScreen = startedSize