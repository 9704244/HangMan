# Made by Symon Kim
import pygame
from FlappyBird import Bird
from Background import Background

pygame.init()
loadScreen = Background.screenSize
running = True
initial = True

while running == True:
    Background.screen.blit(loadScreen, (0,0))
    Background.screen.blit(Bird.birdSize, (Bird.xpos, Bird.ypos))
    pygame.display.update()

    # Enter Game
    if initial == True:
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                loadScreen = Background.startedSize
                initial = False

    # Exit Code

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()