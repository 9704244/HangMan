class Bird:
    import pygame
    from Background import Background

    width = 200
    height = 200
    xpos = Background.width/2 - width/2
    ypos = Background.height/2 - height/2

    loadBird = pygame.image.load("Bird.png")

    birdSize = pygame.transform.scale(loadBird, (width, height))